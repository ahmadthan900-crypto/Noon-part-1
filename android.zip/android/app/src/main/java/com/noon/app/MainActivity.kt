package com.noon.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    // ضع رابط Cloudflare HTTPS الثابت هنا، ولا تستخدم 127.0.0.1 على الهاتف.
    private val BASE_URL = "https://CHANGE-ME.example.com/api/v1"
    private var token: String? = null
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showLogin()
    }
    private fun shell(title: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 36, 28, 24)
            setBackgroundColor(Color.rgb(247,243,236))
        }
        root.addView(TextView(this).apply {
            text = title; textSize = 30f; setTextColor(Color.rgb(91,67,44))
            gravity = Gravity.CENTER; setPadding(0,0,0,22)
        })
        setContentView(root)
    }
    private fun field(hint: String, secret: Boolean=false): EditText {
        return EditText(this).apply {
            this.hint=hint; textSize=16f
            if(secret) inputType= android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            root.addView(this, LinearLayout.LayoutParams(-1,-2))
        }
    }
    private fun btn(label: String, action: () -> Unit) {
        root.addView(Button(this).apply { text=label; setOnClickListener { action() } },
            LinearLayout.LayoutParams(-1,-2))
    }
    private fun showLogin() {
        shell("نون")
        val phone=field("رقم الهاتف")
        val pass=field("كلمة المرور",true)
        btn("تسجيل الدخول") {
            request("POST","/login",JSONObject().put("phone",phone.text.toString()).put("password",pass.text.toString())) { j ->
                token=j.optString("token"); runOnUiThread { showHome() }
            }
        }
        btn("حالة الاتصال") { request("GET","/health",null,auth=false) { j ->
            runOnUiThread { Toast.makeText(this,j.toString(),Toast.LENGTH_LONG).show() }
        }}
    }
    private fun showHome() {
        shell("أهلاً بك في نون")
        btn("عرض آخر المحتوى") {
            request("GET","/feed",null) { j ->
                runOnUiThread {
                    val t=TextView(this).apply { text=j.toString(); textSize=14f; setTextColor(Color.DKGRAY) }
                    root.addView(t)
                }
            }
        }
        btn("تسجيل الخروج") {
            request("POST","/logout",JSONObject()) { token=null; runOnUiThread { showLogin() } }
        }
    }
    private fun request(method:String,path:String,body:JSONObject?,auth:Boolean=true,done:(JSONObject)->Unit) {
        if(BASE_URL.contains("CHANGE-ME")) {
            Toast.makeText(this,"عدّل BASE_URL في MainActivity.kt أولاً",Toast.LENGTH_LONG).show(); return
        }
        thread {
            try {
                val conn=URL(BASE_URL+path).openConnection() as HttpURLConnection
                conn.requestMethod=method; conn.connectTimeout=15000; conn.readTimeout=30000
                conn.setRequestProperty("Content-Type","application/json")
                if(auth && token!=null) conn.setRequestProperty("Authorization","Bearer $token")
                if(body!=null) { conn.doOutput=true; conn.outputStream.use { it.write(body.toString().toByteArray()) } }
                val stream=if(conn.responseCode<400) conn.inputStream else conn.errorStream
                val response=stream.bufferedReader().use { it.readText() }
                val json=JSONObject(response)
                if(conn.responseCode>=400) runOnUiThread { Toast.makeText(this,json.optString("error","حدث خطأ"),Toast.LENGTH_LONG).show() }
                else done(json)
                conn.disconnect()
            } catch(e:Exception) {
                runOnUiThread { Toast.makeText(this,"تعذر الاتصال بالخادم: ${e.message}",Toast.LENGTH_LONG).show() }
            }
        }
    }
}
